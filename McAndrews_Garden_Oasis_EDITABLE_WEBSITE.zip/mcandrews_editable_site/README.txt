MCANDREWS GARDEN OASIS — EDITABLE WEBSITE

This version is built so the owner can manage project photos and videos from an /admin/ page after the site is connected to Netlify + Git Gateway.

WHAT YOU CAN EDIT
- Service photos
- Service names and descriptions
- Project photos
- Add/remove/reorder projects
- Add a YouTube/YouTube Shorts link or direct MP4 URL to show a project video

IMPORTANT
The website is ready for the editor, but the private editor login does NOT work until the site is deployed to Netlify and Netlify Identity + Git Gateway are enabled. This is a one-time setup.

OWNER EDITOR
After setup, open:
https://YOUR-NETLIFY-SITE.netlify.app/admin/

Then log in with the owner account and use “Website Content” to make changes.

HOW VIDEO WORKS
For the easiest option, upload the video to YouTube and paste the YouTube link into the Video URL field. The website automatically displays it in the Videos section.

FREE HOSTING NOTE
Netlify can host the site on its free Netlify subdomain. A custom domain such as yourbusiness.com may cost money separately.

LEAD FORM
The quote form is still configured to send leads through FormSubmit to:
christianmcandrewszg@yahoo.com

FIRST FORM SUBMISSION
FormSubmit may require an email activation/confirmation the first time the live form is used.
